let dls = document.querySelectorAll("#main_nav dl");
const as = document.querySelectorAll("#main_nav h3 a");
const nav = document.getElementById("main_nav");
const bg = document.querySelector(".nav_bg");

dls = [bg, ...dls];

for (let j = 0; j < as.length; j++) {
  as[j].addEventListener("mouseover", function () {
    for (let i = 0; i < dls.length; i++) {
      dls[i].classList.remove("hidden");
      dls[i].classList.remove("dpt2");
      dls[i].classList.add("active");
    }
  });

  nav.addEventListener("mouseleave", function () {
    for (let i = 0; i < dls.length; i++) {
      dls[i].classList.add("hidden");
      dls[i].classList.remove("active");
    }
  });
}
